# 爱回收小程序 估价+券 接口完整文档
> 来源：VM-45131-12836 设备实测（run_js 原生调用 + UI 驱动抓包），2026-11-11
> 网关：`https://dubai-mp.aihuishou.com/dubai-gateway`（POST 路径自动拼在网关后）
> 调用方式：小程序内 `req(91361).A.get/post(path, params)`（webpack 注入拿 require，Ahs-Sign2 由小程序原生生成）

---

## 一、估价主链路（5 步）

### 0. 城市定位 `POST /regions/locate-city-v5`
```json
请求: {"lng": 113.65, "lat": 34.76}
响应: {"cityId": 370, ...}   ← 设备代理城市决定，实测落地 370
```
GET 也支持但实测会失败，用 POST。

### 1. 产品搜索 `POST /recycle-products/search-v11`
```json
请求: {"keyword": "iPhone 17 Pro Max", "cityId": 370, "bizTypes": [1], "page": 1, "size": 10}
```
- ⚠️ `bizTypes` 必须是 **int 数组** `[1]`（传字符串数组 `["RECYCLE"]` 报错）
- 响应 `data.list[0]`: `{"productId": 225362, "name": "苹果 iPhone 17 Pro Max", "maxPrice": 10740, ...}`

### 2. 快估模板 `GET /recycle-products/inquiry/{productId}`
```
参数: queryType=1, productId=225362, cityId=370
```
响应关键字段：
```json
{
  "templateType": 2,
  "couponPrice": 600,
  "productId": 225362, "productName": "苹果 iPhone 17 Pro Max",
  "quickInquiry": {"id": 233, "items": [
    {"id": 1015, "name": "正常进入桌面", "ppvs": [{"id": 2026, "name": "正常开机进入桌面"}]},
    {"id": 1016, "name": "全新包装未拆封", ...}
  ]},
  "finenessInquiry": ..., "isFineness": ...
}
```
- `quickInquiry.items[].id` = 快估题选项 ID（提交时作为 quickInquiryItemId）
- `quickInquiry.items[].ppvs` 原始响应是对象数组，取其中对象的 `id` 作为 ppvId（**要并入 create 的 ppvIds**），不能直接当 int 数组处理

### 3. 完整问卷 `GET /recycle-products/inquiry-items`
```
参数: productId=225362, quickInquiryItemId=1015, cityId=370, templateType=2
```
响应（57KB）：
```json
{
  "templateType": 2,
  "skus": [[2014,3987,2075,2903], ...],   ← 64 个合法 SKU 维度组合（ppvId 四元组）
  "product": {"id": 225362, "name": "...", "topPrice": 10740, "categoryId": 1, "brandId": 52, "bizType": 1},
  "propertyNames": [ ...23 题... ],        ← 见第三节全表
  "guaranteePeriodType": ...,
  "ppvDisabledTips": ..., "ppvIsEnvironmentalRecyclingTips": ...
}
```
- 23 题 = 4 个 SKU 维度题（isSkuProperty:true）+ 19 个功能/外观题
- 每题 `items[]` 为选项，`items[].id` = 选项 ID（ppvId）

### 4. 提交估价 `POST /inquiry/create-v4` ⭐
```json
{
  "ahsAgent": "AHS_MP",
  "productId": 225362,
  "ppvIds": [2026,3987,2014,2903,2075,38346,37333,2114,6982,11663,9625,2045,13842,2100,54562,2106,2102,2808,3168,6947,6949,8712,9507,11210],
  "phenomenonItemIds": [],
  "isEnvironmentalRecycling": false,
  "autoFulfill": false,
  "cityId": 370,
  "templateType": 2,
  "sensors": {"city_id":370,"cityId":370,"innerSource":"","sourcePlatform":"miniapp","sourceAppName":"earth","utmAhs":"","distinctId":"<openid>","unionId":"<unionid>","abtest":"","clickId":""}
}
```
- `ppvIds` = **24 个选项 ID 平铺**（快估题答案 2026 也要并入，共 24 个）
- `sensors` **必填**，缺失返回 `{"sensors":"must not be null"}`；设备内由 `req(48843).Ly()` 生成，Python 可按上述结构静态构造，`distinctId/unionId` 取授权登录返回值
- 响应：`{"inquiryKey": "202611110432150554"}`（仅此一个字段）
- ❌ **不要用** `/inquiry-record/inquiry/create`——那是另一条链路，报 `12624004 询价项策略不存在`

### 5. 价格详情 `GET /inquiry/detail-v2?inquiryKey=xxx`
响应关键字段：
```json
{
  "inquiryKey": "202611110432150554",
  "price": 4540,                      ← 估价（元）
  "inquiryValueIds": [3987,2903,...], ← 回显 24 个 ppvId
  "product": {"id":225362,"name":"苹果 iPhone 17 Pro Max","maxPrice":10740,...},
  "chosenPpv": {"ppvGroups":[         ← 分组回显（设备属性/功能情况/外观情况）
    {"type":1,"name":"设备属性","ppvs":[{"ppnId":315,"ppnName":"存储容量","ppvId":3987,"ppvName":"256G"},...]},
    {"type":2,"name":"功能情况","ppvs":[...]},
    {"type":3,"name":"外观情况","ppvs":[...]}
  ]},
  "protectPriceTime": 10,             ← 保价天数
  "weekReduction": 84074,             ← 周降价
  "templateType": 2, "overDue": false, "isSupportRecycleCart": true
}
```

---

## 二、券接口（同板块）

### A. 加价券 `POST /coupons/common-coupon-plan`
```json
请求: {"inquiryKey": "xxx", "cityId": 370, "pickupType": 5, "bizType": 1}
响应: {
  "availableCoupons": [    ← 当前可用（status:-1）
    {"name":"手机回收加价券","amount":570,"minPriceLimit":4800,"status":-1,
     "startTime":"2026-11-07","endTime":"2026-11-11T23:59:59","isPercent":false,
     "packageCode":"2026110711053845","promotionCode":"2026110617500404",
     "relatedInquiryKey":"xxx", "description":"每笔订单只可使用一张加价券,满额自动加价"},
    ... 按金额降序 10 张 ...
  ],
  "unAvailableCoupons": [...25 张...],
  "waitReceiveCouponNum": 10
}
```
实测档位（满额自动加价，每单限一张）：

| amount | 门槛 minPriceLimit |
|---|---|
| 570 | 4800 |
| 530 | 4000 |
| 520 | 4800 |
| 480 | 4000 |
| 450 | 3000 |
| 420 | 3000 |
| 350 | 2000 |
| 230 | 1200 |
| 120 | 800 |
| 50 | 400 |
| 25 | 200 |

### B. 叠加券
`common-coupon-plan` 的 `availableCoupons` 也会返回当前可用的叠加券。本次手机数码回收叠加券为估价 +1%、满 ¥200、封顶 ¥10，响应中的 `amount` 已是按四舍五入计算后的实际加价金额，可直接用于合计，无需再次计算百分比。

通用活动规则也可通过 `GET /welfare-center/entry-v3?cityId=370` 查询：
```json
响应: {"couponPackages": [{
  "name": "手机数码回收叠加券", "isPercent": true, "percent": 1,
  "minPriceLimit": 200, "maxAwardPrice": 10,        ← +1%，满200，封顶¥10
  "status": -1, "platform": 4,
  "startTime": "2026-11-01", "endTime": "2026-11-30T23:59:58",
  "packageCode": "2026102815385991",
  "categoryLimit": [{"categoryId":28,"categoryName":"无人机"},...]
}]}
```

---

## 三、完整问卷 23 题 × 用户参数对照（productId=225362）

| # | 问题(ppnId) | SKU维度 | 用户三组选项 |
|---|---|---|---|
| 1 | 存储容量(315) | ✓ | 组1=3987(256G) / 组2,3=7396(512G)；其他: 10023(1T),47196(2T) |
| 2 | 购买渠道(314) | ✓ | 2014(大陆国行)；其他: 2015(港澳台官换),2794(海外无锁),2019(海外有锁) |
| 3 | 机身颜色(456) | ✓ | 2903(官方标准色)；其他: 21804(深蓝色) |
| 4 | 剩余保修期(333) | ✓ | 2075(过保或小于1个自然月)；其他: 12479(大于1个自然月) |
| 5 | 电池健康度(4000) | | 38346(85%-94%)；其他: 37329(原装95-100%),37915(80-84%),37328(<80%) |
| 6 | 外观成色(3999) | | 组1,2=37333(轻微划痕/小磕碰) / 组3=37331(屏幕外壳完好)；其他: 37332,37334 |
| 7 | 屏幕显示(350) | | 2114(显示完美无瑕疵)；其他: 2115,8565,2475 |
| 8 | 摄像头功能及维修(1279) | | 6982(无维修更换/官方维修)；其他: 34254,20169,10138 |
| 9 | 苹果账号可退出(343) | | 2100(可退出)；其他: 2101(无法退出) |
| 10 | 生物识别(344) | | 2102(正常)；其他: 2103(无法识别) |
| 11 | 充电功能(346) | | 2106(正常)；其他: 2107(无反应) |
| 12 | 通话功能(325) | | 2045(通话正常)；其他: 2047(异常) |
| 13 | 蓝牙功能(1746) | | 11663(WiFi/蓝牙正常)；其他: 11664(异常) |
| 14 | 还原功能(1364) | | 9625(正常)；其他: 9626(无法还原) |
| 15 | 声音功能(2113) | | 13842(正常)；其他: 13843(无声/异常) |
| 16 | 激活功能(4894) | | 54562(正常可激活)；其他: 54563(无基带/无法激活) |
| 17 | 指南针(529) | | 2808(正常)；其他: 2809(不正常) |
| 18 | 触摸(580) | | 3168(正常)；其他: 3169(失灵/延迟) |
| 19 | 屏幕传感器(1268) | | 6947(光线距离正常)；其他: 6948(不正常) |
| 20 | 振动(1269) | | 6949(正常)；其他: 6950(异常) |
| 21 | 机器重启(1340) | | 8712(无重启卡死)；其他: 8713(有) |
| 22 | 数据连接(1359) | | 9507(正常连电脑)；其他: 9508(无法连接) |
| 23 | 侧键(1669) | | 11210(正常)；其他: 11212(失灵) |

快估题（quickInquiry id=233）：1015=正常进入桌面(ppvId 2026) / 1016=全新未拆封。
**用户三组答案均为"正常进入桌面"→ ppvIds 里含 2026。**

用户表里的空列（屏幕外观/边框背板/机身弯曲/整机维修受潮/无线功能/网络制式/官方维修）在该产品问卷中**不存在对应题目**，无需回答。

---

## 四、三组历史设备实测结果（cityId=370，2026-11-11）

| 组 | 变量 | ppvIds | inquiryKey | 估价 | 最大加价券 | 固定券合计 | 含叠加券到手 |
|---|---|---|---|---|---|---|---|
| 1 | 256G 基准 | 3987+37333 | 202611110432150554 | **¥4540** | +¥530(满4000) | ¥5070 | ¥5080 |
| 2 | 512G | 7396+37333 | 202611110432175367 | **¥5600** | +¥570(满4800) | ¥6170 | ¥6180 |
| 3 | 512G+外观完好 | 7396+37331 | 202611110432195380 | **¥5925** | +¥570(满4800) | ¥6495 | ¥6505 |

金额口径：**固定券合计 = 估价 + 最优固定金额券**，对应 Python 输出的 `total`；**含叠加券到手 = 固定券合计 + 叠加券 amount**，对应 `grandTotal`。叠加券直接采用响应中的实际 `amount`，不再自行计算百分比。

差价：容量 256G→512G = +¥1060；外观 轻微划痕→完好 = +¥325。

---

## 五、订单确认页 fan-out（create 成功后页面自动调用的接口）

```
GET  /inquiries/config-desc {inquiryKey}                          文案配置
POST /coupons/get-brand-gifts-activity-v3 {inquiryKeys:[k]}       品牌加价活动
POST /inquiries/recycle-modes-v4 {inquiryKeys:[k], regionId, distinctId}  回收方式
POST /member/trial-premium-member {cityId, inquiryKeys:[k], pickupType:5, bizType:1, subsidy:true}
GET  /following/is-followed-v2 {inquiryKey, categoryId:1}
POST /inquiry/recommend-ppv-report-v2 {cityId, inquiryKey}        推荐报告
POST /carbon-point/calculate-v2 {inquiryKeys:[k], cityId, bizType:1}  碳积分
POST /inquiry/trial/city-shop-subsidy {cityId, inquiryKey}        城市门店补贴
POST /activity/gradient-increase-trial-v2 {cityId, pickupType:5}  阶梯加价
POST /exchange-activity/match {cityId, inquiryKey, pickupType:5}  以旧换新
POST /inquiry/current-receive {categoryId:1}
POST /front-category/config-v2 {bizTypes:[1,2,3,4,5,7,19,9,10,13,12,14,15,16,17,1000,99], cityId}
POST /shops/service-station-list-v7 {cityId, bizTypes:[...]}      门店列表
POST /regions/overlay-v2 {cityId, categoryIds:[1]}
POST /config/recycle-order/flow-chart-v3 {categoryIds:[1], cityId}
GET  /regions/370/children
```

---

## 六、调用注意事项

### Python 运行配置

| 环境变量 | 用途 |
|---|---|
| `AHS_TOKEN` | **必填**，授权登录返回的 Token |
| `AHS_OPENID` / `AHS_UNIONID` | 授权返回的微信标识，写入 `sensors` |
| `AHS_PROXY` | 可选 HTTP/SOCKS5 代理；SOCKS 需安装 `PySocks` |
| `AHS_DEVICE_ID` | 可选但生产建议设置为固定 UUID；未设置时每个进程重新生成 |

凭据通过安全的环境变量注入，不写入 Python 源码、文档或日志。`Ahs-Session-Id` 每个进程自动生成。脚本输出 `total`（估价+固定券）和 `grandTotal`（再加叠加券）。

### 调用与签名
1. 全程设备内 `run_js` 调 `req(91361).A.get/post`，**禁止外部直连**（无代理=风控危险）
2. webpack 注入：`wx.webpackJsonp.push([[随机id],{},function(r){req=r}])` → `req(91361)`
3. 设备代理易断：`ERR_CONNECTION_CLOSED` → `ctx.change_proxy("410100", type="city")` 后重试
4. `status:-1` = 券可用
5. 快估选项的 ppvId 必须并入 create 的 ppvIds（共 24 个：快估1 + 问卷23）
6. `Ahs-Token` 必填，缺失或失效返回 `1003 用户未登录`；真实请求只有 `Ahs-Sign2`，不要添加 `Ahs-Sign`
7. GET Sign2 使用裸 `querystring.stringify(query)`，不要添加 `query=` 前缀；POST body 必须与发送体逐字节一致
8. 同时存在 URL query 与 POST body 时，两者必须按顺序共同参加 Sign2，不能只签 body
9. 使用 `Ahs-Once-Token` 时，必须同时放入请求头和 Sign2；不用时可完全省略


---

## 七、验证码风控（2026-11-11 实测）

连续高频 create-v4 触发 `3001 请输入验证码`，响应带 `captchaUrl`（4 位扭曲数字图，OSS 直链）。

**处理流程**：
1. 发起 create → 3001 + captchaUrl
2. 下载图片 OCR（4 位数字）
3. 重试：**imgCaptcha 是 query 参数** —— `POST /inquiry/create-v4?imgCaptcha=3256`（不是 body 字段！）
4. 重试签名必须同时包含 `imgCaptcha=3256` 和 `body=<原始JSON>` 两段；只把验证码拼进 URL 而只签 body 会产生错误 Sign2
5. TTL 很短（约 1 分钟内），OCR 到重试要快，否则报 `验证码已失效`
6. 解过一次后有放行窗口，后续 create 直过

本批 Python 在第 9、20 行均真实收到 `3001`，分别 OCR 后使用 `create_inquiry(ppv_ids, img_captcha=...)` 重试成功，详情和券链路也均通过。由此 `imgCaptcha` 与 POST body 联合 Sign2 已完成实网验证。第 21 行随后返回 `12624008 询价次数超上限`，这是独立限额，不能用验证码或盲目重试处理。

**机型问卷差异**（ppvIds 不能跨机型复用，必须按 productId 拉 inquiry-items 校验）。本批 20 个机型均通过指定 SOCKS5 代理实时拉取模板和完整问卷：

| productId | 机型 | 问卷题数 | SKU维度数 | 合法SKU组合数 | quickInquiryItemId |
|---:|---|---:|---:|---:|---:|
| 225362 | iPhone 17 Pro Max | 23 | 4 | 64 | 1015 |
| 225361 | iPhone 17 Pro | 23 | 4 | 48 | 1015 |
| 225366 | iPhone 17 Air | 25 | 3 | 24 | 1033 |
| 225358 | iPhone 17 | 22 | 3 | 16 | 1015 |
| 161415 | iPhone 16 Pro Max | 23 | 4 | 48 | 1015 |
| 161414 | iPhone 16 Pro | 23 | 4 | 64 | 1015 |
| 161412 | iPhone 16 | 22 | 3 | 24 | 1015 |
| 121769 | iPhone 15 Pro Max | 25 | 3 | 24 | 1033 |
| 121436 | iPhone 15 Pro | 25 | 3 | 32 | 1033 |
| 121435 | iPhone 15 | 24 | 2 | 12 | 1033 |
| 98525 | iPhone 14 | 24 | 2 | 12 | 1039 |
| 98528 | iPhone 14 Pro Max | 24 | 2 | 16 | 1039 |
| 98527 | iPhone 14 Pro | 24 | 2 | 16 | 1039 |
| 43513 | iPhone 13 Pro Max | 24 | 2 | 16 | 1039 |
| 43511 | iPhone 13 Pro | 24 | 2 | 16 | 1039 |
| 43510 | iPhone 13 | 24 | 2 | 12 | 1039 |
| 36047 | iPhone 12 Pro Max | 24 | 2 | 12 | 1039 |
| 36046 | iPhone 12 Pro | 24 | 2 | 12 | 1039 |
| 36045 | iPhone 12 | 24 | 2 | 12 | 1039 |
| 32290 | iPhone 11 | 25 | 3 | 24 | 1039 |

iPhone 11 额外有 `1102 网络制式` 题；快估项 ID 也不能按系列猜，必须来自当前 productId 的模板。

## 八、历史设备实测价格汇总（cityId=370，2026-11-11）

以下是早期设备内实测快照，不是本批 Python 报价，也不作为最新价格断言。

| 机型 | 估价 | 最优固定券 | 固定券合计 | 叠加券 amount | 含券合计 |
|---|---:|---:|---:|---:|---:|
| iPhone 17 Pro Max 256G 轻划痕 | ¥4540 | +¥530 | ¥5070 | +¥10 | **¥5080** |
| iPhone 17 Pro Max 512G 轻划痕 | ¥5600 | +¥570 | ¥6170 | +¥10 | **¥6180** |
| iPhone 17 Pro Max 512G 外观完好 | ¥5925 | +¥570 | ¥6495 | +¥10 | **¥6505** |
| iPhone 11 256G（电池70-79%/明显划痕磕碰） | ¥380 | +¥25 | ¥405 | +¥4 | **¥409** |
| iPhone 13 Pro 256G | ¥1000 | +¥120 | ¥1120 | +¥10 | **¥1130** |
| iPhone 13 256G | ¥650 | +¥50 | ¥700 | +¥7 | **¥707** |
| iPhone 12 Pro Max 256G | ¥850 | +¥120 | ¥970 | +¥9 | **¥979** |
| iPhone 12 Pro 256G | ¥680 | +¥50 | ¥730 | +¥7 | **¥737** |

---

## 九、35 组批次预检与 Python 实网进度（2026-11-11）

所有模板、问卷及已执行的估价请求均显式使用指定 SOCKS5 代理，没有外部直连。行号均指不含表头的数据行。

### 参数预检

- 35 行、20 个 productId 的模板和完整问卷全部实时获取成功。
- 34 组的必答题覆盖、选项归属和 SKU 组合合法。
- 第 35 行 iPhone 11 只提供 25 个答案，完整问卷 25 题加快估答案应有 26 个；缺少 `1102 网络制式`。该组未自动补值、未调用 create，其余答案没有未知问题或无效选项。

### 实网执行结果

| 数据行 | 机型 | 估价 | 最优固定券 | total | 叠加券 | grandTotal |
|---:|---|---:|---:|---:|---:|---:|
| 1 | iPhone 17 Pro Max | ¥4710 | +¥530 | ¥5240 | +¥10 | **¥5250** |
| 2 | iPhone 17 Pro Max | ¥5770 | +¥570 | ¥6340 | +¥10 | **¥6350** |
| 3 | iPhone 17 Pro Max | ¥5925 | +¥570 | ¥6495 | +¥10 | **¥6505** |
| 4 | iPhone 17 Pro Max | ¥4110 | +¥530 | ¥4640 | +¥10 | **¥4650** |
| 5 | iPhone 17 Pro Max | ¥4830 | +¥570 | ¥5400 | +¥10 | **¥5410** |
| 6 | iPhone 17 Pro | ¥4490 | +¥530 | ¥5020 | +¥10 | **¥5030** |
| 7 | iPhone 17 Pro | ¥5130 | +¥570 | ¥5700 | +¥10 | **¥5710** |
| 8 | iPhone 17 Pro | ¥3700 | +¥450 | ¥4150 | +¥10 | **¥4160** |
| 9 | iPhone 17 Pro | ¥4400 | +¥530 | ¥4930 | +¥10 | **¥4940** |
| 10 | iPhone Air | ¥2100 | +¥350 | ¥2450 | +¥10 | **¥2460** |
| 11 | iPhone 17 | ¥2960 | +¥350 | ¥3310 | +¥10 | **¥3320** |
| 12 | iPhone 16 Pro Max | ¥3970 | +¥450 | ¥4420 | +¥10 | **¥4430** |
| 13 | iPhone 16 Pro Max | ¥3510 | +¥450 | ¥3960 | +¥10 | **¥3970** |
| 14 | iPhone 16 Pro Max | ¥3965 | +¥450 | ¥4415 | +¥10 | **¥4425** |
| 15 | iPhone 16 Pro | ¥2995 | +¥350 | ¥3345 | +¥10 | **¥3355** |
| 16 | iPhone 16 Pro | ¥3235 | +¥450 | ¥3685 | +¥10 | **¥3695** |
| 17 | iPhone 16 | ¥2520 | +¥350 | ¥2870 | +¥10 | **¥2880** |
| 18 | iPhone 16 | ¥2325 | +¥350 | ¥2675 | +¥10 | **¥2685** |
| 19 | iPhone 15 Pro Max | ¥2490 | +¥350 | ¥2840 | +¥10 | **¥2850** |
| 20 | iPhone 15 Pro Max | ¥2220 | +¥350 | ¥2570 | +¥10 | **¥2580** |

上述 20 组均完成 `create-v4 → detail-v2 → common-coupon-plan`，且 productId、答案回显和券 relatedInquiryKey 校验一致。第 9、20 行均经过真实验证码 OCR 和联合签名重试后成功。

部分机型存在问卷中不可答、但固定在合法 SKU 元组内的值，例如 17 Air 自动补入 `20984 官方标准色`。详情校验只接受能由当前选中 SKU 唯一推导出的隐藏固定值；用户答案仍必须全部回显，任何其他额外值都会判定失败，未放宽成任意子集校验。

第 21 行 iPhone 15 Pro 的 create 返回 HTTP 200、`code=12624008 询价次数超上限`，未重试；第 22–34 行共 13 组未执行，不能记为实网成功。当前合计：20 组成功、1 组限额失败、13 组未执行、1 组缺参跳过。

结构化结果见 `/tmp/sdetail/ahs_batch_results.json`，其中包含成功记录、两次实网验证码验证、限额失败行、未执行行号和缺参跳过原因；文件不含代理或登录态。
