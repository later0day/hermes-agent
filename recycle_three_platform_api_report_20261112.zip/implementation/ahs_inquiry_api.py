# 爱回收估价三接口 — 参数生成方式 + Python 请求脚本（v2，按设备实证修正）
# 实测来源：VM-45131-12836 设备（2026-11-11）
# ⚠️ 估价接口有风控：高频 create-v4 触发 3001 图片验证码（imgCaptcha 走 query 参数过）；
#    设备指纹风控 3003 存在，生产建议走设备内 run_js。本脚本用于报告/研究参考。
#
# v2 修正（全部经设备真实请求验证）：
#   1. 【删除】Ahs-Sign（Sign1）——真实请求根本没有这个头，只有 Ahs-Sign2
#   2. 【修正】GET 的 Sign2 第二段 = querystring.stringify(query)，无 "query=" 前缀
#      （设备实测：md5("Ahs-App-Id=10007&inquiryKey=<key>&Ahs-Timestamp=<ms>&salt=<SALT2>") → code:0）
#   3. 【修正】时间戳单次读取（消除跨秒风险）
#   4. 【修正】Ahs-Token 必填——1003 = "用户未登录"（设备实测：去掉 Token 必返 1003）
#   5. 【新增】Ahs-Device-Id / Ahs-Session-Id（UUIDv4，真实请求携带；实测非必需，
#      但参与风控画像，生产建议带上并保持 Device-Id 稳定）
#   6. 【修正】错误处理：code!=0 抛带服务端原始信息的异常，不再 KeyError 掩盖
#   7. 【新增】3001 验证码处理：OCR 后以 ?imgCaptcha=xxxx（query 参数，非 body）重试

import hashlib
import json
import os
import time
import uuid
from typing import Optional
from urllib.parse import quote

import requests

# ============================================================
# 一、参数生成方式（每个字段怎么来的）
# ============================================================
#
# 【通用 Header 参数】（真实成功请求的完整头集，设备 hook wx.request 实证）
#   Content-Type     : application/json;charset=UTF-8
#   Ahs-App-Id       : 固定 "10007"
#   Ahs-Timestamp    : 当前毫秒时间戳（单次读取）
#   ahs-app-version  : 小程序版本号 "8.5.5"（实测设备值）
#   Ahs-Token        : 登录态 token（32字符）。【必填】缺失 → code:1003 用户未登录
#   Ahs-Sign2        : md5("&".join(过滤空段([
#                          "Ahs-App-Id=10007",
#                          querystring.stringify(query对象),   ← 仅 GET，无前缀！
#                          "body=" + body原始JSON串,           ← 仅 POST，与发送体逐字节一致
#                          "Ahs-Timestamp=" + 毫秒str,
#                          "Ahs-Once-Token=" + t,              ← 仅当 storage 有一次性 token 时
#                          "salt=" + SALT2
#                      ])))
#   Ahs-Device-Id    : UUIDv4（非必需但建议；同一设备保持稳定）
#   Ahs-Session-Id   : UUIDv4（非必需但建议；每会话一个）
#   （Ahs-Once-Token：一次性 token，从 storage 取出即删；成功请求可不带 → 非必需）
#   （Ahs-Sign：真实请求不存在，勿加）
#
# 【接口① create-v4 body 参数】
#   ahsAgent                : 固定 "AHS_MP"
#   productId               : 一次性查询 → POST /recycle-products/search-v11
#                             {keyword:"iPhone 17 Pro Max", cityId, bizTypes:[1], page:1, size:10}
#                             → data.list[0].productId，之后缓存写死
#   ppvIds                  : 答案选项 ID 平铺数组（顺序无关）。生成方式：
#                             a) 一次性拉问卷 GET /recycle-products/inquiry-items
#                                {productId, quickInquiryItemId, cityId, templateType}
#                                → propertyNames[].items[] 建 选项名→ppvId 映射
#                             b) 快估题答案 ppvId（如 2026）必须并入（不在问卷里）
#                             ⚠️ 问卷按机型不同：17PM 23题 / 12、13系列 24题 / iPhone11 25题
#   phenomenonItemIds       : 固定 []
#   isEnvironmentalRecycling: 固定 false
#   autoFulfill             : 固定 false
#   cityId                  : 估价城市码（业务参数，与代理地理位置无强校验；实测 370）
#   templateType            : 来自 GET /recycle-products/inquiry/{productId}?queryType=1
#   sensors                 : 必填（缺了报 {"sensors":"must not be null"}）。结构简单，可静态构造：
#                             {"city_id":C,"cityId":C,"innerSource":"","sourcePlatform":"miniapp",
#                              "sourceAppName":"earth","utmAhs":"","distinctId":"<openid>",
#                              "unionId":"<unionid>","abtest":"","clickId":""}
#                             distinctId=微信openid，unionId=微信unionId（登录接口返回）
#
# 【接口② detail-v2 query 参数】
#   inquiryKey              : 接口① 响应 data.inquiryKey
#
# 【接口③ common-coupon-plan body 参数】
#   inquiryKey / cityId / pickupType=5（上门）/ bizType=1（回收）
#
# 【已知业务码】
#   1003 用户未登录（缺/错 Ahs-Token）——设备实测实锤
#   3001 请输入验证码（响应带 data.captchaUrl，4位数字图；OCR 后 ?imgCaptcha=xxxx 重试，TTL~1分钟）
#   3003 设备状态异常（设备指纹风控）
#   12624004 询价项策略不存在（ppvIds 缺题/与问卷不匹配）
#   12624008 询价次数超上限（停止，等待限额恢复，勿盲目重试）
#
# ============================================================

BASE = "https://dubai-mp.aihuishou.com/dubai-gateway"
APP_ID = "10007"
SALT2 = "797d43d445498964"       # Ahs-Sign2 盐（唯一签名盐）
APP_VERSION = "8.5.5"
AHS_TOKEN = os.getenv("AHS_TOKEN", "")       # 登录态 token，【必填】，由授权流程获取
OPENID = os.getenv("AHS_OPENID", "")         # 微信 openid（sensors.distinctId）
UNIONID = os.getenv("AHS_UNIONID", "")       # 微信 unionid（sensors.unionId）

PROXY_URL = os.getenv("AHS_PROXY", "")        # 可选；SOCKS 代理需安装 PySocks，凭据勿写入源码
PROXIES = {"http": PROXY_URL, "https": PROXY_URL} if PROXY_URL else None
DEVICE_ID = os.getenv("AHS_DEVICE_ID") or str(uuid.uuid4())  # 生产用环境变量固定同一设备值
SESSION_ID = str(uuid.uuid4())                # 每个进程一个会话

# ---------- 静态业务配置（一次性查询后缓存） ----------
PRODUCT_ID = 225362              # 苹果 iPhone 17 Pro Max
CITY_ID = 370
TEMPLATE_TYPE = 2

# 三组答案（ppvIds 平铺，含快估答案 2026）——17PM 专用，换机型必须重新拉问卷校验
ANSWER_SETS = {
    "组1_256G_轻划痕": [2026,3987,2014,2903,2075,38346,37333,2114,6982,11663,9625,2045,13842,2100,54562,2106,2102,2808,3168,6947,6949,8712,9507,11210],
    "组2_512G_轻划痕": [2026,7396,2014,2903,2075,38346,37333,2114,6982,11663,9625,2045,13842,2100,54562,2106,2102,2808,3168,6947,6949,8712,9507,11210],
    "组3_512G_外观完好": [2026,7396,2014,2903,2075,38346,37331,2114,6982,11663,9625,2045,13842,2100,54562,2106,2102,2808,3168,6947,6949,8712,9507,11210],
}


def build_sensors() -> dict:
    return {
        "city_id": CITY_ID, "cityId": CITY_ID, "innerSource": "",
        "sourcePlatform": "miniapp", "sourceAppName": "earth", "utmAhs": "",
        "distinctId": OPENID, "unionId": UNIONID, "abtest": "", "clickId": "",
    }


# ============================================================
# 二、dubai 签名（仅 Sign2；与设备 formatPreRequestData 逐行对应）
# ============================================================
def _md5(s: str) -> str:
    return hashlib.md5(s.encode("utf-8")).hexdigest()


def _qs_stringify(query: dict) -> str:
    """等价 Node querystring.stringify（扁平对象，插入序，值 URL 编码）"""
    return "&".join(f"{k}={quote(str(v), safe='')}" for k, v in query.items())


def make_headers(query: Optional[dict] = None,
                 body_str: Optional[str] = None,
                 once_token: Optional[str] = None) -> dict:
    ts_ms = str(int(time.time() * 1000))  # 单次读取

    parts = [f"Ahs-App-Id={APP_ID}"]
    if query:  # GET：qs 序列化，无 "query=" 前缀（设备实证）
        parts.append(_qs_stringify(query))
    if body_str:  # POST：body 原始 JSON 串（必须与发送体逐字节一致）
        parts.append("body=" + body_str)
    parts.append(f"Ahs-Timestamp={ts_ms}")
    if once_token:  # 一次性 token（有才拼）
        parts.append(f"Ahs-Once-Token={once_token}")
    parts.append(f"salt={SALT2}")
    sign2 = _md5("&".join(parts))

    headers = {
        "Content-Type": "application/json;charset=UTF-8",
        "Ahs-App-Id": APP_ID,
        "Ahs-Timestamp": ts_ms,
        "ahs-app-version": APP_VERSION,
        "Ahs-Token": AHS_TOKEN,
        "Ahs-Sign2": sign2,
        "Ahs-Device-Id": DEVICE_ID,
        "Ahs-Session-Id": SESSION_ID,
    }
    if once_token:
        headers["Ahs-Once-Token"] = once_token
    return headers


class AhsApiError(RuntimeError):
    """业务错误：携带服务端原始信息，不再 KeyError 掩盖"""
    def __init__(self, stage: str, payload: dict):
        self.stage, self.payload = stage, payload
        super().__init__(
            f"[{stage}] HTTP {payload.get('_http')} code={payload.get('code')} "
            f"msg={payload.get('resultMessage') or payload.get('message') or payload.get('debugMessage')}"
        )


def _check(stage: str, resp: requests.Response) -> dict:
    try:
        data = resp.json()
    except ValueError:
        raise AhsApiError(stage, {"_http": resp.status_code, "code": -1,
                                  "resultMessage": f"非JSON响应: {resp.text[:200]}"})
    if not isinstance(data, dict):
        raise AhsApiError(stage, {"_http": resp.status_code, "code": -1,
                                  "resultMessage": "JSON 响应不是对象"})
    data["_http"] = resp.status_code
    if not 200 <= resp.status_code < 300:
        data.setdefault("resultMessage", f"HTTP {resp.status_code}")
        raise AhsApiError(stage, data)
    if data.get("code") != 0:
        raise AhsApiError(stage, data)
    if not isinstance(data.get("data"), dict):
        data["resultMessage"] = "成功响应缺少 data 对象"
        raise AhsApiError(stage, data)
    return data


# ============================================================
# 三、三个接口
# ============================================================
def create_inquiry(ppv_ids: list, img_captcha: Optional[str] = None) -> str:
    """提交估价 → inquiryKey。触发 3001 时 OCR 响应里的 captchaUrl，
    把识别结果作为 img_captcha 重试（query 与 body 共同签名，TTL~1分钟）。"""
    body = {
        "ahsAgent": "AHS_MP",
        "productId": PRODUCT_ID,
        "ppvIds": ppv_ids,
        "phenomenonItemIds": [],
        "isEnvironmentalRecycling": False,
        "autoFulfill": False,
        "cityId": CITY_ID,
        "templateType": TEMPLATE_TYPE,
        "sensors": build_sensors(),
    }
    body_str = json.dumps(body, separators=(",", ":"), ensure_ascii=False)
    query = {"imgCaptcha": img_captcha} if img_captcha else None
    resp = requests.post(
        f"{BASE}/inquiry/create-v4",
        params=query,
        data=body_str.encode("utf-8"),
        headers=make_headers(query=query, body_str=body_str),
        proxies=PROXIES,
        timeout=15,
    )
    return _check("create-v4", resp)["data"]["inquiryKey"]


def get_detail(inquiry_key: str) -> dict:
    """估价详情 → price / chosenPpv / protectPriceTime 等"""
    query = {"inquiryKey": inquiry_key}
    resp = requests.get(f"{BASE}/inquiry/detail-v2",
                        params=query,
                        headers=make_headers(query=query),
                        proxies=PROXIES, timeout=15)
    return _check("detail-v2", resp)["data"]


def get_coupon_plan(inquiry_key: str) -> dict:
    """券方案 → availableCoupons（status:-1=可用）"""
    body = {"inquiryKey": inquiry_key, "cityId": CITY_ID,
            "pickupType": 5, "bizType": 1}
    body_str = json.dumps(body, separators=(",", ":"))
    resp = requests.post(f"{BASE}/coupons/common-coupon-plan",
                         data=body_str.encode("utf-8"),
                         headers=make_headers(body_str=body_str),
                         proxies=PROXIES, timeout=15)
    return _check("coupon-plan", resp)["data"]


def pick_best_coupon(plan: dict, price: int) -> Optional[dict]:
    """最优回收固定金额券，排除购买券、延保券及百分比券。"""
    best = None
    for c in (plan.get("availableCoupons") or []):
        if c.get("promotionType") == 1 and c.get("status") == -1 \
                and not c.get("isPercent") and c.get("amount") is not None \
                and price >= c.get("minPriceLimit", 0):
            if best is None or c["amount"] > best["amount"]:
                best = c
    return best


def pick_stack_coupon(plan: dict, price: int) -> Optional[dict]:
    """最优回收叠加券；响应 amount 已是本次实际加价，直接求和。"""
    best = None
    for c in (plan.get("availableCoupons") or []):
        if c.get("promotionType") == 4 and c.get("status") == -1 \
                and c.get("isPercent") and c.get("amount") is not None \
                and price >= c.get("minPriceLimit", 0):
            if best is None or c["amount"] > best["amount"]:
                best = c
    return best


# ============================================================
# 四、主流程
# ============================================================
def main():
    if not AHS_TOKEN:
        raise RuntimeError("AHS_TOKEN 环境变量必填，缺失必返 1003 用户未登录")
    for name, ppv_ids in ANSWER_SETS.items():
        try:
            key = create_inquiry(ppv_ids)
        except AhsApiError as e:
            if e.payload.get("code") == 3001:
                cap_url = (e.payload.get("data") or {}).get("captchaUrl", "")
                print(f"[{name}] 触发验证码: {cap_url} → OCR 后以 img_captcha 重试")
            raise
        detail = get_detail(key)
        plan = get_coupon_plan(key)
        price = detail["price"]
        best = pick_best_coupon(plan, price)
        stack = pick_stack_coupon(plan, price)
        fixed_amount = best["amount"] if best else 0
        stack_amount = stack["amount"] if stack else 0
        total = price + fixed_amount
        grand_total = total + stack_amount
        print(f"[{name}] inquiryKey={key} price={price} "
              f"coupon=+{fixed_amount} total={total} "
              f"stack=+{stack_amount} grandTotal={grand_total}")
        time.sleep(1.5)  # 控制频率，避免触发 3001


if __name__ == "__main__":
    main()

# 历史锚点（2026-11-11 设备实测；价格随时间变化，不作固定断言）：
# 组1_256G_轻划痕   price=4540  best=530(满4000)  total=5070  stack=10  grandTotal=5080
# 组2_512G_轻划痕   price=5600  best=570(满4800)  total=6170  stack=10  grandTotal=6180
# 组3_512G_外观完好 price=5925  best=570(满4800)  total=6495  stack=10  grandTotal=6505
