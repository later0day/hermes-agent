# 拍机堂（pjt）小程序询价 API 链

> appid `wxfb796f037077edb6`，app-id 头 `xcx152403`，API 域名 `sjapi-mini.aihuishou.com`，埋点 `bi-log.aihuishou.com/trace/log/pjt`。
> ⚠️ 命名陷阱：该 appid 在旧文档里被记为"爱回收旧版 v31"，但 v34+ 包实际业务是**拍机堂**（爱回收旗下 toB 询价/拍卖平台，登录响应里是 wxAccountId/merchantId 商户体系）。看到 p_pjt_* 方案、pjt 埋点、sjapi-mini 域名即为此 app。

## 请求结构

- 业务数据接口全部是 **POST + JSON body**（`content-type: application/json`），用 GET 打返回 `code:20200101 ServletException`
- 源码中路径带 `/java/` 前缀，运行时由 `api_base_url` 替换：`https://sjapi-mini.aihuishou.com/` + 路径去掉 `/java` 前缀
- 响应统一 `{code, resultMessage, data}`，`code:200` = 成功；HTTP 状态恒 200，错误在 body 里
- 通用头：`app-id: xcx152403`、`app-name: xcx`、`platform: miniapp`、`timestamp`(毫秒)、`chromosome`（签名头，但配置链不校验——实测**抓包流量里的 chromosome 原值可直接重放**使用，无时间绑定或绑定极松）

## 配置链（全部匿名可调，服务器 IP 裸 curl 实测 200）

| 接口 | 方法/参数 | 返回 |
|------|----------|------|
| `/sj-inspection-api/xcx-foundation/category` | POST `{}` | 25 个品类（手机=1、笔记本=5…） |
| `/sj-inspection-api/xcx-foundation/brand` | POST `{"categoryId":1}` | 品牌列表（苹果=52、华为=9…151 个） |
| `/sj-inspection-api/xcx-foundation/product` | POST `{"brandId":52,"categoryId":1}` | 机型列表（productId+名称+icon） |
| `/sj-inspection-api/price-property/v3/app/xcx/step/product/by-inspection?productId=N` | GET，仅 query | 3 步估价问卷（题数随机型：27~35 题；step1 的 4 题 isSkuProperty=true 是定 SKU 档位的关键；选项 isPreferred=true 为推荐默认项） |
| `/opt-privilege/quote/merchant/mini-program?membershipId=1` | GET | 询价 VIP 剩余次数（remainingTimes），匿名也返 |

- 非法 productId 返回 `code:20200100 "型号未上架, productId:N onLineStrategyNo:M"`（泄露内部策略号）

## 询价（出钱的一步，by-ppv）

```
POST /supply-api/mini-inquiry-price/price-info/by-ppv
{"productId": 328681, "pricePropertyValueIds": [2014, 3987, ...]}
```
- 源码函数 `exports.inquiry`；结果查询 `POST /supplier-api/mini-inquiry-price/price-info/by-mini-inquiry-id`（`exports.inquiry2`，裸调 404，不要走这条）
- **必须 `Access-Token` 头**：无 token → `{"code":400,"resultMessage":"token为空！"}`；无效/过期/截断的 token → `"Token已失效"`。**⚠️ token 是 32 位 hex 全长，截断一位都报"Token已失效"，会被误读成过期——先核对长度再下结论**
- **关键实测修正：未绑商户账号的老端点 token 也能询价出钱**（设备登录脚本每天跑出来的 token，拿去直接调 by-ppv 返 200 带价格）。"未绑商户=无询价资格"是错误结论，bind 只影响小程序端价格展示，不影响接口返回
- **33 个问卷属性必须全传**：缺任何一个返回 `code:19021020`，resultMessage 列出全部缺失属性 ID 清单（可拿来回填）
- 响应字段：`guidePrice`（指导价）、`highPrice`（最高价）、`platformReferencePrice`、`levelName`（成色等级 A+~K）、`skuId`、`itemCode`、`priceSourceType`。实测同机型完美机 A+ 8800 vs 全坏机 K 3888，价格引擎真实响应选项组合
- 响应 `code:1e7` = 询价次数达上限（前端弹窗"您的询价次数已达上限"并跳会员页）

## 商户绑定（bind）流程

token 不够时小程序走绑定（v34 源码 `pages/price-search/index` 提交询价时 mobile 为空即触发）：

```
POST /opt-auth/mini-program-v2/bind
{"loginCode": <wx.login 的 code>, "phoneCode": <wx.getPhoneNumber 按钮授权的 e.detail.code>}
→ 200 后 accessToken/mobile 落 storage
```

- ⚠️ `phoneCode` **不是短信验证码**，是 `button open-type="getPhoneNumber"` 用户点授权后 `e.detail.code`；服务端拿它找微信换真实手机号
- ✅ **bind 实测成功且会自动注册商户**：新鲜 loginCode + 新鲜 phoneCode → 200，响应 `newMerchant:1` + 新 `merchantId` + 32位 accessToken（86400s）+ 掩码 mobile。**手机号无需预先注册拍机堂**——bind 即注册；源码里"请选择与拍机堂账户一致的手机号码"的提示只在支付核验等个别流程出现，不挡 bind 本身。绑定 token 实测：询价VIP remainingTimes=300、by-ppv 出价 200
- 校验顺序逐层：缺字段 → `code:600` 逐字段报错；loginCode 假 → `code:37100012 "微信登录凭证无效"`；loginCode 真 + phoneCode 假/过期 → `code:37100013 "手机号授权凭证无效"`
- **资源中心 `get_bindinfo` 的 code 可以直接当 phoneCode 用，前提是新鲜**：bindinfo 返回 `{code(64hex), encryptedData, iv}`，code 即该号最近一次手机号授权的一次性码——近期授权过的号拿来即绑成功（实测 200），存放太久的号 → 37100013（码失效，不是格式不对）。encryptedData+iv 参数路径服务端不收（报 phoneCode 不能为空），三件套里只有 code 字段有用
- **完整可自动化 bind 链**（全实测）：分配 xdd 号（号池动态入池，`no_wxid` 是暂时的，隔天重试可能就有号）→ `wxsdk.sub_request("/code/fetch", params={wxid, appid, category:"xdd", num:2})` 取新鲜 loginCode（⚠️ `data.code` 是**两个码的 list**，[0]=loginCode；同 wxid 两小时冷却，重复取报"正在获取或两小时内已成功获取"）→ `wxsdk.get_bindinfo(wxid)` 取 phoneCode → POST bind → accessToken
- 绑定一次性：绑过的微信号后续 login 直接带 token，每天重跑登录刷新即可（tokenExpiresIn=86400）

## 登录端点版本（两个端点并行存活）

| 端点 | body | 未绑商户账号 |
|------|------|--------------|
| `sjapi.aihuishou.com/opt-auth/mini-program/login`（老，v31 备份包现行使用） | `{"code": wxcode}` | **照发 32位hex token（24h 有效），未绑商户也发**——登录脚本每天量产，token 存资源池 `custom_save("pjt_token_xcx")` |
| `sjapi-mini.aihuishou.com/opt-auth/mini-program-v2/login`（v34 小程序自身启动用） | `{"loginCode": wxcode}` | `accessToken=null`，只给 wxAccountId+openId |

- ⚠️ 老端点从**外部服务器 curl 会 405**（网关环境限制），但设备端小程序正常调通——判断端点死活以设备流量为准，别被本机 405 误导成"已下线"
- 登录脚本成功判定规则是流量匹配 `*program_login*` + 含 "accessToken" —— **v2 的 URL 是 `mini-program-v2/login`，不含 `program_login` 字串，且 `"accessToken":null` 也含该子串**，v34 切换后这条规则既可能漏判也可能误判，看采集成功率别只看 login_success 计数
- 历史 collect-log 里 `login_success` 的 ret 能看到完整请求/响应（含真实 accessToken），可直接提取复用（24h 内有效）

## 设备会话陷阱

- 设备当前页面可能是**上一任务的残留会话**：xcx_status 显示 webview 开着别家 H5（如转转估价页），不代表当前 bind_task 的业务。以 `device__info.target_app` + 新鲜 res_data 的域名分布为准——残留会话的 res_data 文件 mtime 是旧的。
- 询价方案（p_pjt_*）若 x-log 结果全是 `{"code":0,"result":false}`，**先查采集脚本本身**（没走询价流程/没传全 33 属性值/没用资源池 token），而不是账号权限——by-ppv 用未绑商户的 token 实测能出价。注意 `result_code:1` 的记录 `result` 字段只是微信号（=登录成功），不代表采到价格。

## 商户凭证的替代路径（web 控制台）

拍机堂有 web 商户控制台 `https://www.paijitang.com`（React SPA，静态资源在 OSS）：登录口 `POST /sapi/auth/login`（账号+密码，带验证码），登录后有拍卖列表/详情/价格等商户能力（前端路由 `/backend/bidding/*`，真实接口走 `/sapi/*` 同域网关）。有商户账号密码时优先走 web 采集，绕开微信登录 + 商户绑定整套链路。未实测验证，仅确认端点存在。