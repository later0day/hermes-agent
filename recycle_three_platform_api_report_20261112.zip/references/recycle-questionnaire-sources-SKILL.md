---
name: recycle-questionnaire-sources
description: Use when 需要拉回收平台机型估价问卷/SKU配置。转转/爱回收/拍机堂三家匿名接口源。
tags: [recycle, questionnaire, zhuanzhuan, aihuishou, paijitang, sku, reverse-engineering]
---

# 回收平台估价问卷匿名采集源

## 触发场景
- 需要某机型在转转帮卖/爱回收/拍机堂的估价问卷（题目+选项 ID+合法 SKU 组合）
- 换机型前要校验业务方给的答案 ID 集
- 搭建估价数据管道，找免登录的配置拉取入口

## 核心模式

**问卷全部匿名可拉；只有出价/create 才要登录态。** 名称→问卷两步：搜索接口拿 ID → 问卷接口拿题目。三家全程无需账号。

## 代理纪律

- **禁止裸发**——一律走用户提供的国内住宅代理（socks5），目标站点有 WAF/风控，本机 IP 直连会污染出口画像
- requests 用 `socks5h://` scheme（DNS 也走代理）；PySocks 不在环境里就装到独立目录（`pip install -t /tmp/xxx PySocks` + `sys.path.insert`），不动系统包
- 代理冷启动可能首个 CONNECT 返 `05 Connection refused`——重试一次即通，不是白名单限制；判代理死活用 SOCKS5 握手（`05 02` 选认证 + `01 00` 认证成功）而不是某个目标的连通性
- 代理凭据只进内存，不写文件/日志/skill

## 完整流程（端到端已验证 2026-11-11，12 机型 12/12 通过）

```
输入：机型名（如 "iPhone 13"）
转转：   ① 搜索 → (cateId, brandId, modelId)  → ② 问卷
爱回收： ① 搜索 → productId                    → ② 问卷
拍机堂： ① 搜索 → productId（与爱回收同 ID）   → ② 问卷
```

---

# 接口文档

## 一、转转帮卖（零鉴权）

公共头：`User-Agent: Mozilla/5.0 (Linux; Android 14) MicroMessenger/8.0.79 MiniProgramEnv/android`，`Referer: https://servicewechat.com/`。无签名、无登录态。

### 1.1 搜索：名称 → 三 ID
```
GET https://app.zhuanzhuan.com/zzopen/zzbmlogic/getWordkeySearchResultNew?keyword=<名称>
```
| 参数 | 说明 |
|---|---|
| keyword | 必填，机型名（如 `iPhone 13`），需 URL 编码 |

- 成功判据：`respCode == 0`
- 响应：`respData.keyWordResult[]`，每项字段：
  - `modelId` 机型 ID（问卷用）
  - `name` 机型名（精确匹配输入名用，如 `"iPhone 13"`）
  - `cateId` 品类 ID（手机=101）
  - `brandId` 品牌 ID（苹果=10530）
  - `brandName`/`cateName` 品牌/品类名
  - `maxPrice` 最高回收价（搜索展示价=顶配完美成色上限，非实际估价）
  - `showPrice`/`saleType`/`pic`/`modelType`/`groupName` 等辅助字段
- **一次调用拿齐问卷所需三 ID**（cateId/brandId/modelId）

### 1.2 问卷：getSkuBayesParamPage
```
GET https://app.zhuanzhuan.com/zzopen/zzbmlogic/getSkuBayesParamPage
    ?cateId=101&brandId=10530&modelId=<modelId>&evalPlanType=B&channel=BM_0040
```
| 参数 | 说明 |
|---|---|
| cateId | 必填且**必须正确**（手机=101）；填错时 respCode=0 但问卷为空（静默失败，最坑） |
| brandId | 必填但**值不校验**（带 10530 即可，填错照样返回） |
| modelId | 必填且必须正确（搜索返回的 modelId） |
| evalPlanType | 固定 `B`（帮卖） |
| channel | 固定 `BM_0040` |

- 成功判据：`respCode == 0` **且** `respData.bayesParamDtoList` 非空（防空响应陷阱）
- 响应：`respData.modelName`（回显机型名，可二次校验）+ `respData.bayesParamDtoList[]` 每题：
  - `itemId` 题目 ID / `itemName` 题目名
  - `required` 1=必答
  - `options[]: {id, name, disabled...}` 选项
- 题量示例：iPhone 11~14 系均 11 题；iPhone 18 Pro(1499188) 12 题

### 1.3 转转注意事项
- zzbmlogic 的 search/getModelList/queryModelList/searchModelList 等同族猜测端点全 403（要登录态），**别浪费时间穷举**——搜索只认 `getWordkeySearchResultNew`（该端点在 H5 首页 bundle 的 API 表里有定义，调用方在懒加载 chunk）
- 转转帮卖打包任务会报 `COMM_LIB_LAYOUT_CHANGED`（包结构不被打包器识别），**不用重试**
- 若端点失效：抓 `https://m.zhuanzhuan.com/u/node_ssr_bm/home?needHideHead=1&bizType=c2b&__waneednotauth=1&channel=BM_WECHAT14` 的 JS bundle（s1.zhuanstatic.com/u/bmmain/）grep `/zzopen/` 拿最新端点表
- 同品牌批量场景 cateId/brandId 可缓存写死，实际只需搜 modelId

## 二、爱回收 dubai H5 网关（匿名签名）

公共头（⚠️ 2026-11-12 修正：不是 ahs-sign 单段，是 **Ahs-Sign2 段式签名**，与小程序同构）：
| Header | 值 |
|---|---|
| Ahs-App-Id | `10002`（H5/PC=Browser 环境；小程序网关是 10007=Wechat_Main，别混） |
| Ahs-Token | 留空（匿名） |
| Ahs-Timestamp | **毫秒**时间戳（不是秒级！与签名段内一致） |
| Ahs-Sign2 | `md5(segments.join("&"))`，segments 按序过滤空段后拼接 |
| Content-Type | `application/json;charset=UTF-8` |

**盐值表**（从 H5 bundle `main.*.js` 模块 51361 环境表挖到，逐个环境一份）：
| 环境 | ahsAppId | salt |
|---|---|---|
| **Browser（H5/PC，本匿名链用这个）** | 10002 | `34694d9d74954784` |
| Wechat_Main（微信小程序 dubai-mp） | 10007 | `797d43d445498964` |
| 头条/抖音/支付宝系/原生App | 10010/10021/10014/10013/10015/10016/10018/10004/10003 | 各一份（模块 51361 里全列着） |

**Ahs-Sign2 段结构**（按此顺序，空段 filter 掉）：
```
["Ahs-App-Id=10002",
 "<querystring.stringify(query)>",      ← 仅 GET，无 "query=" 前缀
 "body=<JSON.stringify(body) compact>",  ← 仅 POST，与发送体逐字节一致
 "Ahs-Timestamp=<毫秒>",
 "Ahs-Once-Token=<t>",                  ← 仅当有一次性 token
 "salt=34694d9d74954784"].filter(Boolean).join("&") → md5
```
实测（2026-11-12）：search-v11 + inquiry-items 用这套全过（code:0）；早期 skill 里写的 `ahs-sign=md5(秒ts+盐1)` 单段头是错的，会报 `1002 签名验证失败`。

### 2.1 搜索：search-v11
```
POST https://dubai.aihuishou.com/dubai-gateway/recycle-products/search-v11
Body: {"keyword":"iPhone 13", "cityId":114, "bizTypes":[1], "page":1, "size":10}
```
| 参数 | 说明 |
|---|---|
| keyword | 必填，机型名 |
| cityId | 城市 ID（114=郑州，搜索不敏感） |
| bizTypes | **必须 int 数组** `[1]`（回收业务），字符串数组会报错 |
| page / size | 分页 |

- 响应：`data.products[]`，每项 `id`（productId）/`name`（格式 `"苹果 iPhone 13"` 带品牌前缀）/`maxPrice`/`imageUrl`
- 精确匹配规则：`name == "苹果 " + 输入名`

### 2.2 问卷：inquiry-items
```
GET https://dubai.aihuishou.com/dubai-gateway/recycle-products/inquiry-items
    ?cityId=114&productId=<pid>          （需要时再加 &quickInquiryItemId=<qid>）
```
| 参数 | 说明 |
|---|---|
| productId | 必填，搜索返回的 id |
| cityId | 城市 ID |
| quickInquiryItemId | 可选，快估项 ID（拉快估题时用） |

- 成功判据：`code == 0`
- 响应：
  - `data.propertyNames[]` 每题：`id`(ppnId)/`name`/`isSkuProperty`/`items[]:{id, ppvIds[], name}`（选项 ppvId 取 `ppvIds[0]`）
  - `data.skus[]` 合法 SKU 组合元组表（校验 SKU 维度组合合法性用）
  - `data.templateType` 模板类型（2=标准问卷）
- 与小程序版（dubai-mp, appid 10007）差异：H5 版把快估题"运行情况"内嵌在 propertyNames 里（题数多 1）；ppvId 体系两边一致
- 问卷细节/机型矩阵/出价链路（create-v4 必须登录态 + 3001 验证码）见 skill `aihuishou-api-dependency`

## 三、拍机堂（chromosome 可重放）

公共头：
| Header | 值 |
|---|---|
| referer | `https://servicewechat.com/wxfb796f037077edb6/34/page-frame.html`（拍机堂 v34） |
| app-id | `xcx152403` |
| app-name | `xcx` |
| platform | `miniapp` |
| ahs-language | `zh-CN` |
| content-type | `application/json` |
| timestamp | 毫秒时间戳 |
| access-token | 留空（匿名） |
| chromosome | 抓包原值直接重放（结构 `base64|hash|miniapp|1.100 32 build`），配置链不校验时效 |

### 3.1 搜索：xcx-foundation/product
```
POST https://sjapi-mini.aihuishou.com/sj-inspection-api/xcx-foundation/product
Body: {"keyword":"iPhone 13"}
```
- ⚠️ **必须 POST JSON**；GET 报 ServletException
- 响应：`data[]`，每项 `productId`/`productName`（带 `"苹果 "` 前缀）/`icon`
- **拍机堂与爱回收 productId 完全相同**（实测 12 个 iPhone 机型一一相等）

### 3.2 问卷：by-inspection
```
GET https://sjapi-mini.aihuishou.com/sj-inspection-api/price-property/v3/app/xcx/step/product/by-inspection
    ?productId=<pid>
```
- 成功判据：`code == 200`（注意不是 0）；非法 productId 返 `code:20200100 型号未上架`
- 响应：`data[]` 按 step 分组（step1 物品信息 isSkuProperty=true 定档位 / step2 成色 / step3 功能），每步 `properties[]:{id, name, isSkuProperty, pricePropertyValues[]:{id, value}}`
- 题量随机型 27~35（SKU 4+成色 8+功能 23 左右）
- 完整 API 链（含出价 by-ppv、商户 bind）见 `miniapp-traffic-analysis/references/paijitang-inquiry-api.md`

---

## 产物校验
- 爱回收/拍机堂同属一套 ppvId 体系（如 314=购买渠道、2014=大陆国行），答案 ID 可跨这两家参考；转转是独立 ID 体系
- 拉到问卷先建 "题名+选项名→ID" 映射，再校验业务方答案表：每个 ID 在映射里 + 每道必答题有答案 + SKU 维度组合在 skus 元组表里
- 转转问卷校验必须看 `bayesParamDtoList` 非空（cateId 错静默空）；拍机堂看 `code==200`

## 已知机型 ID 锚点

| 机型 | ahs=pjt productId | 转转 modelId | 转转 maxPrice |
|---|---|---|---|
| iPhone 11 | 32290 | 2193 | 705 |
| iPhone 11 Pro | 32291 | 2191 | 930 |
| iPhone 11 Pro Max | 32292 | 2192 | 1115 |
| iPhone 12 mini | 36044 | 31468 | 705 |
| iPhone 12 | 36045 | 31458 | 920 |
| iPhone 12 Pro | 36046 | 31459 | 1315 |
| iPhone 12 Pro Max | 36047 | 31469 | 1620 |
| iPhone 13 mini | 43512 | 58383 | 1255 |
| iPhone 13 | 43510 | 58384 | 1435 |
| iPhone 13 Pro | 43511 | 58386 | 2025 |
| iPhone 13 Pro Max | 43513 | 58387 | 2400 |
| iPhone 14 | 98525 | 95637 | 1740 |
| iPhone 14 Pro | 98527 | 95638 | 2770 |
| iPhone 14 Pro Max | 98528 | 95639 | 3085 |
| iPhone 17 Pro Max | 225362 | — | — |
| iPhone 18 Pro | — | 1499188 | — |

苹果常量：转转 cateId=101、brandId=10530。落盘总表 `/tmp/sdetail/name_to_id_map.json`。